# VEDA Assistant

An Android personal assistant prototype with a local Qwen model. The intended design keeps AI inference on-device and uses explicit user approval for consequential actions.

## Current prototype

- Android Kotlin/Jetpack Compose chat UI.
- Local Qwen3 0.6B `.litertlm` model loading through LiteRT-LM.
- Model file is selected by the user and copied into private app storage; it is not packaged in the APK.
- Backend foundation and action-policy tests are included, but Android chat currently uses the local model path.

## Build and model setup

See [`android/README.md`](android/README.md).

## Safety

No payment execution, credential access, shell/root access, unrestricted accessibility automation, or unattended message sending. Actions must be separately implemented and policy-gated.
