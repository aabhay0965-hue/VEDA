# VEDA Android app

VEDA is an early Android prototype with a local Qwen chat path powered by LiteRT-LM. No AI API key or remote model provider is used.

## Local model setup

1. Install/build the Android app.
2. Open VEDA and tap **Load Qwen model**.
3. Select the downloaded `.litertlm` Qwen3 0.6B file (the approximately 347 MB `nothink` variant).
4. Wait for the status to say **Qwen loaded · local and offline**.
5. Send a message. Generation runs on-device.

The app copies the selected model to its private app files directory. The model is not bundled in the APK. If you uninstall VEDA, its private copy is removed; keep the original download in Downloads.

## Build

Open this `android/` folder in Android Studio. Use JDK 17, Android SDK 35, and allow Gradle to resolve dependencies. The app uses:

- Android Gradle Plugin 8.10.1
- Kotlin 2.2.0
- LiteRT-LM Android 0.16.1

The first build requires an internet connection to download Gradle dependencies. Runtime chat itself does not call an AI API.

## Current limitations

- The local model is only a chat engine; Android actions are not implemented or enabled.
- Model load/generation speed and memory usage must be tested on the target phone.
- This project snapshot has not yet been verified with an Android SDK build. Do not treat it as a production-ready APK.
