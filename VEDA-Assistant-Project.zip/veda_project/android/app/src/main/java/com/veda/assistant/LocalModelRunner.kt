package com.veda.assistant

import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.runBlocking

/** Owns LiteRT-LM on one background thread. No network or API provider is used. */
class LocalModelRunner {
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()
    private var engine: Engine? = null
    private var conversation: Conversation? = null

    fun load(modelPath: String, onResult: (Result<Unit>) -> Unit) {
        executor.execute {
            try {
                closeResources()
                val candidate = Engine(EngineConfig(modelPath = modelPath))
                candidate.initialize()
                val candidateConversation = candidate.createConversation()
                engine = candidate
                conversation = candidateConversation
                onResult(Result.success(Unit))
            } catch (error: Throwable) {
                onResult(Result.failure(error))
            }
        }
    }

    fun send(message: String, onToken: (String) -> Unit, onComplete: (Result<Unit>) -> Unit) {
        executor.execute {
            val activeConversation = conversation
            if (activeConversation == null) {
                onComplete(Result.failure(IllegalStateException("Load a model first.")))
                return@execute
            }
            try {
                runBlocking {
                    activeConversation.sendMessageAsync(message).collect { token -> onToken(token) }
                }
                onComplete(Result.success(Unit))
            } catch (error: Throwable) {
                onComplete(Result.failure(error))
            }
        }
    }

    fun close() {
        executor.execute { closeResources() }
        executor.shutdown()
    }

    private fun closeResources() {
        conversation?.close()
        conversation = null
        engine?.close()
        engine = null
    }
}
