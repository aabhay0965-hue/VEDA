package com.veda.assistant

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VedaApp(this) }
    }
}


private data class ChatMessage(val text: String, val fromUser: Boolean)


@Composable
fun VedaApp(activity: MainActivity) {
    val messages = remember {
        mutableStateListOf(ChatMessage("Hey! I'm VEDA, your personal assistant.", false))
    }
    val runner = remember { LocalModelRunner() }
    DisposableEffect(runner) { onDispose { runner.close() } }
    var input by remember { mutableStateOf("") }
    var modelStatus by remember { mutableStateOf("No local model loaded") }
    var isSending by remember { mutableStateOf(false) }
    val mainHandler = remember { Handler(Looper.getMainLooper()) }

    val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            modelStatus = "Importing model…"
            try {
                val modelFile = copyModelToAppStorage(activity, uri)
                modelStatus = "Loading model… this can take a while"
                runner.load(modelFile.absolutePath) { result ->
                    mainHandler.post {
                        modelStatus = result.fold(
                            { "Qwen loaded · local and offline" },
                            { "Couldn't load model: ${it.message ?: "unknown error"}" }
                        )
                    }
                }
            } catch (error: Exception) {
                modelStatus = "Couldn't import model: ${error.message ?: "unknown error"}"
            }
        }
    }

    MaterialTheme(colorScheme = lightColorScheme(
        primary = Color(0xFF355C50),
        background = Color(0xFFF6F7F5),
        surface = Color.White
    )) {
        Column(modifier = Modifier.fillMaxSize().background(Color(0xFFF6F7F5))) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier.size(42.dp).background(Color(0xFF355C50), CircleShape),
                    contentAlignment = Alignment.Center
                ) { Text("V", color = Color.White, fontWeight = FontWeight.Bold) }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("VEDA", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("On-device personal assistant", style = MaterialTheme.typography.labelMedium, color = Color.Gray)
                }
            }
            Surface(
                modifier = Modifier.fillMaxWidth().weight(1f),
                color = Color.White,
                shape = RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp)
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) { items(messages) { message -> MessageBubble(message) } }
            }
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)) {
                Text(modelStatus, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = { modelPicker.launch(arrayOf("application/octet-stream", "*/*")) }) {
                        Text("Load Qwen model")
                    }
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth().padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Message VEDA...") },
                    shape = RoundedCornerShape(24.dp),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White
                    ),
                    maxLines = 4
                )
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = {
                        val text = input.trim()
                        if (text.isNotEmpty() && !isSending) {
                            messages.add(ChatMessage(text, true))
                            val replyIndex = messages.size
                            messages.add(ChatMessage("", false))
                            input = ""
                            isSending = true
                            runner.send(
                                text,
                                onToken = { token -> mainHandler.post {
                                    messages[replyIndex] = messages[replyIndex].copy(text = messages[replyIndex].text + token)
                                } },
                                onComplete = { result -> mainHandler.post {
                                    if (result.isFailure) {
                                        messages[replyIndex] = ChatMessage(
                                            "Local model error: ${result.exceptionOrNull()?.message ?: "unknown error"}", false
                                        )
                                    }
                                    isSending = false
                                } }
                            )
                        }
                    },
                    enabled = input.isNotBlank() && !isSending
                ) { Text("Send") }
            }
            if (isSending) Text("Qwen is generating…", color = Color.Gray, modifier = Modifier.padding(start = 20.dp, bottom = 6.dp))
        }
    }
}


private fun copyModelToAppStorage(activity: MainActivity, uri: Uri): File {
    val target = File(activity.filesDir, "veda_qwen_model.litertlm")
    activity.contentResolver.openInputStream(uri).use { input ->
        requireNotNull(input) { "Android couldn't open the selected file." }
        target.outputStream().use { output -> input.copyTo(output) }
    }
    require(target.length() > 0L) { "The selected model file is empty." }
    return target
}


@Composable
private fun MessageBubble(message: ChatMessage) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            color = if (message.fromUser) Color(0xFF355C50) else Color(0xFFF0F2EF),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth(0.86f)
        ) {
            Text(
                text = message.text,
                color = if (message.fromUser) Color.White else Color(0xFF202520),
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 11.dp)
            )
        }
    }
}
