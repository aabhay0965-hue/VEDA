from app.policy import Decision, classify_action


def test_known_low_risk_action_is_allowlisted():
    assert classify_action("reminder.draft").decision is Decision.ALLOW


def test_external_side_effect_requires_approval():
    assert classify_action("message.send").decision is Decision.APPROVAL_REQUIRED


def test_payment_is_prohibited():
    assert classify_action("payment.execute").decision is Decision.DENY


def test_unknown_action_is_denied_by_default():
    assert classify_action("device.do_anything").decision is Decision.DENY
