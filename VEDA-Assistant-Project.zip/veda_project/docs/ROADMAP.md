# Roadmap

1. Confirm app requirements and supported Android version.
2. Create Compose app shell and navigation.
3. Define backend API models and deny-by-default action policy.
4. Add backend tests and CI.
5. Add secure authentication/configuration and provider abstraction.
6. Implement chat UI and backend integration.
7. Implement reminders with Android-native APIs.
8. Add calendar intents and user-confirmed flows.
9. Add WhatsApp message draft via Android intent; never bypass review.
10. Device test, accessibility review, privacy/security review.
