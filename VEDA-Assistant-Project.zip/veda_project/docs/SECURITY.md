# Security model (initial)

## Default-deny
Unknown tools/actions are denied. The backend may classify requests but must not execute Android actions.

## Allowed without confirmation (planned)
- General chat and informational responses
- Open an explicitly allowlisted app or website, after Android-side user consent where needed
- Prepare a reminder draft

## Approval required (planned)
- Send or publish a message
- Create, edit, or delete calendar entries
- Share files/data
- Any action with external side effects

## Prohibited
- Payments or financial transactions
- Reading passwords, tokens, or credential stores
- Root/shell/code execution
- Bypassing Android permissions or security prompts
- Unrestricted accessibility automation
- Installing apps without user action
- Changing or disabling its own safety policy

## Privacy
- Store the minimum data needed.
- Keep secrets out of Git and logs.
- Provide clear permission explanations and user-controlled revocation.
- Do not send personal data to a model/provider without user awareness and consent.
